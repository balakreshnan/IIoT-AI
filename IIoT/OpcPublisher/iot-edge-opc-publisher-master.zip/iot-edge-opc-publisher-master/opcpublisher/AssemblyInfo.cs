﻿
[assembly: System.Reflection.AssemblyCompany("Microsoft")]
[assembly: System.Reflection.AssemblyConfiguration("Release")]
[assembly: System.Reflection.AssemblyDescription("Azure IoT Edge OPC Publisher Module")]
[assembly: System.Reflection.AssemblyFileVersion("2.3.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("2.3.0")]
[assembly: System.Reflection.AssemblyProduct("opcpublisher")]
[assembly: System.Reflection.AssemblyTitle("opcpublisher")]
[assembly: System.Reflection.AssemblyVersion("2.3.0.0")]
